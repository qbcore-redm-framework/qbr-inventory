# qb-weapons
Weapon Logic Script For QB-Core
